function mouseOver() { // mouse over the login and sign up button
  document.getElementById("log").style.backgroundColor="rgb(228, 94, 228)";
}

function mouseOut() { // mouse out the login and sign up button
  document.getElementById("log").style.backgroundColor = "white";}


