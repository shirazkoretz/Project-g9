from flask import Blueprint, render_template, session

# header blueprint definition
header = Blueprint('header', __name__, static_folder='static', static_url_path='/header', template_folder='templates')




@header.route('/logout', methods=['GET' , 'POST'])
def logout_fun():
    session['logged_in'] = False
    session['username'] = ' '
    return render_template('homepage.html')