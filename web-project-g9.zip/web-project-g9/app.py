from flask import Flask

from datetime import timedelta





###### App setup
app = Flask(__name__)
app.config.from_pyfile('settings.py')
app.permanent_session_lifetime = timedelta(hours=3)

###### Pages
## Homepage
from pages.homepage.homepage import homepage
app.register_blueprint(homepage)

## About
from pages.about.about import about
app.register_blueprint(about)

## cookies
from pages.cookies.cookies import cookies
app.register_blueprint(cookies)

## trays
from pages.trays.trays import trays
app.register_blueprint(trays)

## questions
from pages.questions.questions import questions
app.register_blueprint(questions)

## contact us
from pages.contact.contact import contact
app.register_blueprint(contact)



## cart
from pages.cart.cart import cart
app.register_blueprint(cart)

## cart_trays
from pages.cart_trays.cart_trays import cart_trays
app.register_blueprint(cart_trays)

## login
from pages.login.login import login
app.register_blueprint(login)



## Page error handlers
from pages.page_error_handlers.page_error_handlers import page_error_handlers
app.register_blueprint(page_error_handlers)


###### Components
## Main menu
from components.main_menu.main_menu import main_menu
app.register_blueprint(main_menu)

## header
from components.header.header  import header
app.register_blueprint(header)

## footer
from components.footer.footer  import footer
app.register_blueprint(footer)


