from utilities.db.db_manager import DBManager
from flask import render_template, session

dbManager = DBManager()

class DB_classector:
    __connection = None
    __cursor = None


    def getQuestions(self):
        query = "select * from questions"
        query_result = dbManager.fetch(query)
        return query_result

    def getHours(self):
        query_hours = "select * from hours"
        query_result = dbManager.fetch(query_hours)
        return query_result

    def getTrays(self):
        query_trays = "select * from trays"
        query_result = dbManager.fetch(query_trays)
        return query_result

    def finishOrderTray(self,Email,DT,TrayName,phone,fullName,pickUpDate,pickUpHour):
        queryInsert = "INSERT INTO fortray (Email, DT, TrayName,phone,FullName, pickUpDate, pickUpHour) values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (
            Email, DT, TrayName, phone, fullName, pickUpDate, pickUpHour)
        dbManager.commit(query=queryInsert)


    def contactus(self,Email, DT, Full_Name, phone, comment):
        queryInsert = "INSERT INTO leavedetails (Email, DT, FullName, customerPhone, commentDetail) values ('%s', '%s', '%s', '%s', '%s')" % (
        Email, DT, Full_Name, phone, comment)
        dbManager.commit(query=queryInsert)

    def getCookies(self):
        query_cookies = "select * from cookies"
        query_result = dbManager.fetch(query_cookies)
        return query_result

    def getQuantities(self):
        query_quantities = "select * from quantities"
        query_result = dbManager.fetch(query_quantities)
        return query_result

    def getusers(self,user):
        query_user = "select * from customers WHERE  email ='%s';" % user
        query_result = dbManager.fetch(query=query_user)
        return query_result

    def getPassword(self,user):
        query_pass = "select password from customers WHERE  email ='%s';" % user
        query_result = dbManager.fetch(query=query_pass)
        return query_result

    def gellallCustomer(self):
        query_users = "select * from customers"
        query_result = dbManager.fetch(query=query_users)
        return query_result

    def registerCustomer(self, email, fullname, phone, password):
        queryInsert = "INSERT INTO customers (email, fullName, phone, password) values ('%s', '%s', '%s', '%s')" % (
            email, fullname, phone, password)
        dbManager.commit(query=queryInsert)


    def insertToCart(self,cookie_name,quan, price, image, user):
         query_contains = dbClass_conn.getTempOrder(user)
         leng= len(query_contains)
         x=False
         for i in range(leng):
             cookie = query_contains[i][1]
             quantity = query_contains[i][2]
             product_num= query_contains[i][0]
             if (cookie==cookie_name):
                 quan1 = int(quan) + int(quantity)
                 dbClass_conn.updateProduct(user, quan1, product_num)
                 x= True
         if (x ==False ):
              queryInsert = "insert into temporder (c_Name,quantity,pricePerGram,image,totalPrice, customer) values ('%s', '%s', '%s', '%s', '%s', '%s')" % (
              cookie_name, quan, price, image, ((int(quan)) / 100) * int(price), user)
              dbManager.commit(query=queryInsert)


    def getTempOrder(self, user):
        query_temp_order = "select * from temporder WHERE customer ='%s';" % user
        query_result_order = dbManager.fetch(query=query_temp_order)
        return query_result_order

    def deleteFromTempOrder(self, user, id):
        query_temp_order = "delete from temporder WHERE customer ='%s' and product_num= '%s';" % (user, id)
        dbManager.commit(query=query_temp_order)


    def updateProduct(self, user, quantity, product_num):
        query= "UPDATE temporder set quantity=('%s') WHERE customer=('%s') and product_num=('%s')" % (quantity, user, product_num )
        dbManager.commit(query=query)
        pricepergram= "select pricePerGram from temporder WHERE product_num ='%s'and customer= '%s';" % (product_num, user)
        query_result_price = dbManager.fetch(query=pricepergram)
        price1 = [i[0] for i in query_result_price]
        price= price1[0]
        Totalprice= ((int(quantity)) / 100) * int(price)
        query2= "UPDATE temporder set totalPrice=('%s') WHERE customer=('%s') and product_num=('%s')" % (Totalprice, user, product_num )
        dbManager.commit(query=query2)


    def finishOrder(self, fullName, Email, phone, comment, pickUpDate, pickUpHour ):
        queryInsertOrder = "INSERT INTO orders (customerName, customerEmail, customerPhone, comment, pickUpDate, pickUpHour ) values ('%s', '%s', '%s', '%s', '%s', '%s')" % (
            fullName, Email, phone, comment, pickUpDate, pickUpHour  )
        dbManager.commit(query=queryInsertOrder)
        queryOrderID= "select * from lastOrder"
        user1= session.get('username')
        query_result = dbManager.fetch(query=queryOrderID)
        orderID=query_result[-1][0]
        query_contains = dbClass_conn.getTempOrder(user1)
        xx= len(query_contains)

        for i in range (xx):
                cookie= query_contains[i][1]
                quan = query_contains[i][2]
                price = query_contains[i][5]

                dbClass_conn.insertOrderContains(orderID, cookie, quan, price )
                product_num= query_contains[i][0]
                dbClass_conn.deleteFromTempOrder(user1, product_num )



    def insertOrderContains(self, orderID, c_name, quan, price):
        queryInsertOrdercontains = "INSERT INTO ordercontains ( orderID, c_Name, quantity, totalPrice ) values ('%s', '%s', '%s', '%s')" % (
            orderID, c_name, quan, price)
        dbManager.commit(query=queryInsertOrdercontains)



dbClass_conn = DB_classector()

