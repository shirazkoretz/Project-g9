from flask import Blueprint, render_template,  request, redirect, session, url_for
from datetime import datetime
from utilities.db.db_manager import DBManager
from utilities.connectionDBClass.DB_connection import DB_classector
dbClass_conn = DB_classector()



# cart blueprint definition
cart = Blueprint('cart', __name__, static_folder='static', static_url_path='/cart', template_folder='templates')


# Routes
@cart.route('/cart')
def index():
    query_result_hours = dbClass_conn.getHours()
    user1= session.get('username')
    query_result_order = dbClass_conn.getTempOrder(user1)
    query_result_quan= dbClass_conn.getQuantities()
    xx = len(query_result_order)
    sum= 0
    for i in range(xx):
        sum= sum+ query_result_order[i][5]

    return render_template('cart.html', hours=query_result_hours, orders=query_result_order, quans=query_result_quan, sum= sum)

@cart.route('/delete/select/<product_num>')
def deleteProduct(product_num):
    user= session.get('username')
    dbClass_conn.deleteFromTempOrder(user, product_num)
    return redirect('/cart')


@cart.route('/update/select/<product_num>')
def updateProduct(product_num):
    user= session.get('username')
    quan = request.values['quantity']
    dbClass_conn.updateProduct( user, quan, product_num)
    return redirect('/cart')



@cart.route('/cartfinish', methods=['POST', 'GET'])
def finish_order():
    if request.method == 'POST':
        error = ""
        user1 = session.get('username')
        query_result_order = dbClass_conn.getTempOrder(user1)
        if len(query_result_order) == 0:
             error= "you do not have any products in your cart!"
             return render_template('cart.html', error=error)

        else:
            fullName = request.form['fullname']
            Email = request.form['email']
            phone = request.form['phone']
            comment = request.form['comments']
            pickUpDate= request.form['orderdate']
            pickUpHour= request.form['pickUpHour']
            dbClass_conn.finishOrder(fullName, Email, phone, comment, pickUpDate, pickUpHour )

    return redirect('/cart')
