from flask import Blueprint, render_template
from utilities.db.db_manager import DBManager

# trays blueprint definition
trays = Blueprint('trays', __name__, static_folder='static', static_url_path='/trays', template_folder='templates')


# Routes

@trays.route('/trays')
def index():
    query = "select * from trays"
    dbManager = DBManager()
    query_result = dbManager.fetch(query)
    return render_template('trays.html',trays=query_result)