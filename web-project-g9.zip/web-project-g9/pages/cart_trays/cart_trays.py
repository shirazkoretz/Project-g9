from flask import Blueprint, render_template,  request, redirect
from datetime import datetime
from utilities.connectionDBClass.DB_connection import DB_classector

# cart_trays blueprint definition
cart_trays = Blueprint('cart_trays', __name__, static_folder='static', static_url_path='/cart_trays'

                    , template_folder='templates')
dbClass_conn = DB_classector()


# Routes
@cart_trays.route('/cart_trays', methods=['GET', 'POST'])
def index():
    query_result_hours = dbClass_conn.getHours()
    query_result_trays = dbClass_conn.getTrays()
    return render_template('cart_trays.html', hours=query_result_hours, trays=query_result_trays)


@cart_trays.route('/cart_tray_finish', methods=['GET', 'POST'])
def finish_order_tray():
    if request.method == 'POST':
        Email = request.form['email']
        DT = datetime.now()
        TrayName = request.form['trayname']
        phone= request.form['phone']
        fullName= request.form['fullname']
        pickUpDate = request.form['orderdate']
        pickUpHour = request.form['pickUpHour']
        dbClass_conn.finishOrderTray(Email,DT,TrayName,phone,fullName,pickUpDate,pickUpHour)

    return redirect('/cart_trays')
