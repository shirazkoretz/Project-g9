
function phonenumber(inputtxt) //function that check the validation of a phone
{
  let phoneno = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
    if(inputtxt.value.match(phoneno)){
         let match= false;

         SubmitpageSignUp(match);

          return true;
        }
    else
        {
        alert("You need to put Phone number with 10 digits: ##########");
        return false;
        }
}

  function checkValidsignup(phone){ // this function check the input- if it's valid (empty)
      var i,y , valid=true;
      y = document.getElementsByClassName("inputSignup");
  // A loop that checks every input field in the current tab:

    for (i = 0; i < y.length; i++) {
    // If a field is empty...
         if (y[i].value == "") {
                 // add an "invalid" class to the field- change the input color to red:
            y[i].className += " invalid";
            // and set the current valid status to false:
              valid = false;
         }

    }
            // If the valid status is true, mark field as valid:
    if (valid==true) {
        phonenumber(phone);
         }

        // return valid; // return the valid status
}

function SubmitpageSignUp(match){ // function the submit the page
    var x=match
    if(x == false){
            document.getElementById("signup").submit();
            document.getElementById("signup").reset();
            return true;
    }
    else{
      return false;

    }
}

function checkValidLogin(){ // this function check the input- if it's valid (empty)
      var i,y , valid=true;
      y = document.getElementsByClassName("inputLogin");
  // A loop that checks every input field in the current tab:

    for (i = 0; i < y.length; i++) {
    // If a field is empty...
         if (y[i].value == "") {
                 // add an "invalid" class to the field- change the input color to red:
            y[i].className += " invalid";
            // and set the current valid status to false:
              valid = false;
         }

    }
            // If the valid status is true, mark field as valid:
    if (valid==true) {
       SubmitpageLogin();
         }

        // return valid; // return the valid status
}

function SubmitpageLogin(){ // function the submit the page

            document.getElementById("login").submit();
            document.getElementById("login").reset();
            return true;
}