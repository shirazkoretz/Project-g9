from flask import Blueprint, render_template,  request, redirect,session, flash
from utilities.db.db_manager import DBManager
from utilities.connectionDBClass.DB_connection import DB_classector

# login blueprint definition
login = Blueprint('login', __name__, static_folder='static', static_url_path='/login', template_folder='templates')
dbClass_conn = DB_classector()


# Routes
@login.route('/login', methods=['GET', 'POST'])
def index():
    return render_template('login.html')

@login.route('/loginform', methods=['GET', 'POST'])
def loginFunc():
   if request.method == 'POST':
       error= ""
       user = request.form['user']
       password = request.form['password']

       query_result= dbClass_conn.getusers(user)
       query_pass_result= dbClass_conn.getPassword(user)


       if len(query_result) == 0:
           error = 'You do not have an account in morrocookies'
           return render_template('login.html', error=error)


       else:
           pass1 = [i[0] for i in query_pass_result]
           if ( pass1[0] == password):
               flash('You were successfully logged in')
               session.permanent= True
               session['logged_in'] = True
               session['username'] = user
               return redirect('/homepage')
           else:
                error = 'Your password do not match'

   return render_template('login.html', error=error)

@login.route('/signup', methods=['GET', 'POST'])
def signupFunc():
    query_result = dbClass_conn.gellallCustomer()
    email= request.form['email']
    fullname= request.form['fullname']
    phone= request.form['phone']
    password= request.form['pass']
    if len(query_result)!=0 :
        email1 = [i[0] for i in query_result]
        if (email==email1[0]):
            error= 'You already have an acount in morrocookies'
            return render_template('login.html', error=error)
    dbClass_conn.registerCustomer(email, fullname, phone, password)
    flash('welcome to morrocookies')
    session['logged_in'] = True
    session['username'] = email


    return redirect('/homepage')