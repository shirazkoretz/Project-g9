from flask import Blueprint, render_template,  request, redirect, url_for
from datetime import datetime
from utilities.connectionDBClass.DB_connection import DB_classector



# contact blueprint definition
contact = Blueprint('contact', __name__, static_folder='static', static_url_path='/contact', template_folder='templates')


# Routes
@contact.route('/contact',  methods=['GET', 'POST'])
def index():
    return render_template('contact.html')


@contact.route('/contactus', methods=['GET', 'POST'])
def contact_us():
    if request.method == 'POST':
        Email = request.form['email']
        DT = datetime.now()
        Full_Name = request.form['fullname']
        phone = request.form['phone']
        comment = request.form['comments']
        dbClass_conn = DB_classector()
        dbClass_conn.contactus(Email, DT, Full_Name, phone, comment)
    return redirect('/contact')




