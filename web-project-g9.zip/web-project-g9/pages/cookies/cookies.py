from flask import Blueprint, render_template, request, redirect, session, url_for
from utilities.db.db_manager import DBManager
from utilities.connectionDBClass.DB_connection import DB_classector
from decimal import Decimal




# cookies blueprint definition


cookies = Blueprint('cookies', __name__, static_folder='static', static_url_path='/cookies', template_folder='templates')
dbClass_conn = DB_classector()


# Routes
@cookies.route('/cookies')
def index():
    query_result_cookies= dbClass_conn.getCookies()
    query_result_quantities= dbClass_conn.getQuantities()
    return render_template('cookies.html',cookies=query_result_cookies, quantities=query_result_quantities)



@cookies.route('/finish_order/select/<cookie_name>')
def finish_order(cookie_name):
    if request.method == 'GET':
        if session.get('logged_in') == True:
            error=""
            quan= request.values['quantity']
            price= request.values['price']
            image= request.values['picture']
            user= session.get('username')

            dbClass_conn.insertToCart(cookie_name,quan, price, image, user)
    return redirect('/cookies')


