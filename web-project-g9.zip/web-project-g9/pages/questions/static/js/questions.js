function Qustion(id) { // Check if the Answer display, and if isnt diaplsy the answer
    var x=id;

  if (x.style.display !=  "block" ) {
    x.style.display = "block";
  }
  else {
    x.style.display = "none";

  }
}