from flask import Blueprint, render_template
from utilities.connectionDBClass.DB_connection import DB_classector

# questions blueprint definition
questions = Blueprint('questions', __name__, static_folder='static', static_url_path='/questions', template_folder='templates')


# Routes
@questions.route('/questions')
def index():
    dbClass_conn = DB_classector()
    query_result = dbClass_conn.getQuestions()
    return render_template('questions.html', Questions=query_result)